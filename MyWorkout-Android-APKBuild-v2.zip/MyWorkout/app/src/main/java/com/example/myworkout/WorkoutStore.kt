package com.example.myworkout

import android.content.Context
import java.text.SimpleDateFormat
import java.util.*

object WorkoutStore {
    private const val PREF = "workout"
    private val days = arrayOf("일", "월", "화", "수", "목", "금", "토")
    fun get(context: Context, day: Int): String = context.getSharedPreferences(PREF, 0).getString("day_$day", default(day)) ?: default(day)
    fun set(context: Context, day: Int, value: String) = context.getSharedPreferences(PREF, 0).edit().putString("day_$day", value).apply()
    fun today(context: Context): String { val cal=Calendar.getInstance(); return get(context, cal.get(Calendar.DAY_OF_WEEK)-1) }
    fun dayName(day:Int)=days[day]
    private fun default(day:Int)=when(day){1->"휴식";2->"가슴 + 삼두\n벤치프레스 4세트\n인클라인 덤벨프레스 3세트\n푸쉬다운 3세트";3->"등 + 이두\n랫풀다운 4세트\n바벨로우 3세트\n덤벨컬 3세트";4->"휴식";5->"어깨\n밀리터리프레스 4세트\n사이드레터럴레이즈 4세트\n리어델트 3세트";6->"하체\n스쿼트 4세트\n레그프레스 3세트\n레그컬 3세트";7->"가슴 + 등\n벤치프레스 3세트\n풀업 3세트\n케이블플라이 3세트";else->"휴식"}
}
