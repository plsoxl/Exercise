package com.example.myworkout

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews
import java.util.*

class WorkoutWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = update(context)

    companion object {
        fun update(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, WorkoutWidget::class.java))
            val prefs = context.getSharedPreferences("routine", Context.MODE_PRIVATE)
            val day = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1
            val workout = prefs.getString("day_$day", "휴식")?.ifBlank { "휴식" } ?: "휴식"
            val done = prefs.getBoolean("completed_${java.text.SimpleDateFormat("yyyyMMdd", Locale.KOREA).format(Date())}", false)
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.workout_widget)
                views.setTextViewText(R.id.widgetWorkout, workout.substringBefore('\n'))
                views.setTextViewText(R.id.widgetExercises, if (done) "✅ 오늘 운동 완료" else workout.substringAfter('\n', "앱에서 루틴을 확인하세요"))
                manager.updateAppWidget(id, views)
            }
        }
    }
}
