package com.example.myworkout

import android.app.*
import android.content.*
import android.os.Build
import java.util.*

class WorkoutAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val channelId = "workout"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channelId, "운동 알림", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val i = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1
        val prefs = context.getSharedPreferences("routine", Context.MODE_PRIVATE)
        val workout = prefs.getString("day_$i", "오늘 운동")?.ifBlank { "오늘 운동" } ?: "오늘 운동"
        val open = PendingIntent.getActivity(
            context, 101, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, channelId) else Notification.Builder(context)
        builder.setSmallIcon(android.R.drawable.ic_menu_my_calendar)
            .setContentTitle("오늘의 운동 🏋️")
            .setContentText(workout.substringBefore('\n'))
            .setStyle(Notification.BigTextStyle().bigText(workout))
            .setContentIntent(open)
            .setAutoCancel(true)
        if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            nm.notify(10, builder.build())
        }
        MainActivity.scheduleNextAlarm(context)
        WorkoutWidget.update(context)
    }
}
