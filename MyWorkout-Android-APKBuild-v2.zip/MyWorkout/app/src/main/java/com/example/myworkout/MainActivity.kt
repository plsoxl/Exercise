package com.example.myworkout

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val days = arrayOf("일", "월", "화", "수", "목", "금", "토")
    private val prefs by lazy { getSharedPreferences("routine", MODE_PRIVATE) }
    private val inputs = mutableListOf<EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        requestNotificationPermission()
        buildDayInputs()
        refreshToday()

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            saveRoutines()
            scheduleNextAlarm(this)
            WorkoutWidget.update(this)
            refreshToday()
            Toast.makeText(this, "저장했어요. 매일 오후 6시에 알림이 설정됩니다.", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.completeButton).setOnClickListener {
            prefs.edit().putBoolean("completed_${todayKey()}", true).apply()
            refreshToday()
            WorkoutWidget.update(this)
            Toast.makeText(this, "오늘 운동 완료! 💪", Toast.LENGTH_SHORT).show()
        }
    }

    private fun buildDayInputs() {
        val container = findViewById<LinearLayout>(R.id.dayContainer)
        val defaults = arrayOf(
            "휴식",
            "가슴 + 삼두\n벤치프레스 4세트\n인클라인 덤벨프레스 3세트\n케이블 플라이 3세트\n푸쉬다운 3세트",
            "등 + 이두\n풀업 4세트\n바벨로우 4세트\n랫풀다운 3세트\n컬 3세트",
            "휴식",
            "어깨\n밀리터리프레스 4세트\n사이드 레터럴레이즈 4세트\n리어델트 3세트",
            "하체\n스쿼트 4세트\n레그프레스 3세트\n레그컬 3세트\n카프레이즈 4세트",
            "가슴 + 등\n벤치프레스 3세트\n랫풀다운 3세트\n덤벨프레스 3세트\n시티드로우 3세트"
        )
        days.forEachIndexed { i, day ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 10, 0, 4)
            }
            val label = TextView(this).apply {
                text = day + "요일"
                textSize = 18f
            }
            val edit = EditText(this).apply {
                hint = "예: 가슴 + 삼두\n벤치프레스 4세트\n..."
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                minLines = 2
                maxLines = 6
                setText(prefs.getString("day_$i", defaults[i]))
            }
            row.addView(label)
            row.addView(edit, LinearLayout.LayoutParams(-1, -2))
            container.addView(row)
            inputs.add(edit)
        }
    }

    private fun saveRoutines() {
        prefs.edit().apply {
            inputs.forEachIndexed { i, e -> putString("day_$i", e.text.toString().trim()) }
            apply()
        }
    }

    private fun todayIndex() = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1
    private fun todayKey() = SimpleDateFormat("yyyyMMdd", Locale.KOREA).format(Date())

    private fun refreshToday() {
        val i = todayIndex()
        val workout = prefs.getString("day_$i", "휴식").orEmpty().ifBlank { "휴식" }
        val done = prefs.getBoolean("completed_${todayKey()}", false)
        findViewById<TextView>(R.id.todayText).text = "${days[i]}요일\n$workout${if (done) "\n\n✅ 오늘 운동 완료" else ""}"
    }

    private fun requestNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
        }
    }

    companion object {
        fun scheduleNextAlarm(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, WorkoutAlarmReceiver::class.java)
            val pi = PendingIntent.getBroadcast(context, 100, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 18)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (!after(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR, 1)
            }
            if (android.os.Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            } else if (android.os.Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            }
        }
    }
}
